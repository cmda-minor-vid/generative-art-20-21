<!-- Vergeet je niet de comments uit te zetten voordat je begint met typen? 💬 -->

# Procesverslag

## Over
* **Naam:** `voornaam + achternaam`
* **Klas:** `vid-1/vid-2`
* **Minor:** `Visual Interface Design`
* **Favoriete dier:** `Zeeotters zijn te gek!`
* **Startniveau:** `blauw/rood/zwart`

## Concept

`Beschrijf in het algemeen je concept van je project.`

## Features

`Wat zijn de features in het project dat je gemaakt hebt? Waar kan ik op klikken? Waar zit de interactie?`

## Onderzoek & inspiratie
`Schrijf wat over je onderzoek en je inspiratie voor het project. Hoe kwam je concept tot stand?`

## Voortang

`Schrijf hier een klein logboekje met je voortgang per week.`

### Week-1
`Wat heb je gedaan? Wat ging goed? Wat kon beter?`

### Week-2
`Wat heb je gedaan? Wat ging goed? Wat kon beter?`

### Week-3
`Wat heb je gedaan? Wat ging goed? Wat kon beter?`


## Bronnenlijst

* `Link naar bron 1`
* `Link naar bron 2`
* `Link naar bron 3`